package com.example.atlas

import android.content.Context
import java.util.Locale
import java.util.Timer
import java.util.TimerTask
import kotlin.random.Random

class TemperatureSensorManager(
    private val context: Context,
    private val dbHelper: DatabaseHelper
) {
    private var timer: Timer? = null
    private val MAX_SAFE_TEMP = 35.0 // Corregido: sin "const"

    fun startMonitoring(intervalMs: Long = 3000, onNewReading: (SensorData) -> Unit) {
        stopMonitoring()
        timer = Timer()
        timer?.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                val currentTemp = generateSimulatedTemperature()
                val currentHumidity = 40.0 + Random.nextDouble(20.0)
                val status = if (currentTemp > MAX_SAFE_TEMP) "ALERTA_TEMPERATURA" else "NORMAL"

                val reading = SensorData(
                    temperature = String.format(Locale.US, "%.2f", currentTemp).toDouble(),
                    humidity = String.format(Locale.US, "%.2f", currentHumidity).toDouble(),
                    status = status
                )

                dbHelper.logSensorData("Temperature", reading.temperature)
                onNewReading(reading)
            }
        }, 0, intervalMs)
    }

    fun stopMonitoring() {
        timer?.cancel()
        timer = null
    }

    private fun generateSimulatedTemperature(): Double {
        val baseTemp = 24.0
        val noise = (Random.nextDouble() - 0.45) * 15.0
        return baseTemp + noise
    }
}