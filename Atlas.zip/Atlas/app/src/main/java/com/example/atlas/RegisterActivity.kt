package com.example.atlas

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        dbHelper = DatabaseHelper(this)

        val etRegisterUsername = findViewById<EditText>(R.id.etRegisterUsername)
        val etRegisterPassword = findViewById<EditText>(R.id.etRegisterPassword)
        val etConfirmPassword = findViewById<EditText>(R.id.etConfirmPassword)
        val btnRegisterSubmit = findViewById<Button>(R.id.btnRegisterSubmit)
        val btnBackToLogin = findViewById<Button>(R.id.btnBackToLogin)

        btnRegisterSubmit.setOnClickListener {
            val user = etRegisterUsername.text.toString().trim()
            val pass = etRegisterPassword.text.toString().trim()
            val confirmPass = etConfirmPassword.text.toString().trim()

            if (user.isEmpty() || pass.isEmpty() || confirmPass.isEmpty()) {
                Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (pass != confirmPass) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (pass.length < 4) {
                Toast.makeText(this, "La contraseña debe tener al menos 4 caracteres", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (dbHelper.registerUser(user, pass)) {
                Toast.makeText(this, "Usuario '$user' registrado exitosamente", Toast.LENGTH_LONG).show()
                finish()
            } else {
                Toast.makeText(this, "Error: El nombre de usuario ya existe", Toast.LENGTH_SHORT).show()
            }
        }

        btnBackToLogin.setOnClickListener {
            finish()
        }
    }
}