package com.example.atlas

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "AtlasOT.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        val createUsersTable = "CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT)"
        db.execSQL(createUsersTable)

        val createSensorTable = "CREATE TABLE sensor_logs (log_id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, value REAL, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)"
        db.execSQL(createSensorTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS sensor_logs")
        onCreate(db)
    }

    // Encriptación SHA-256 para contraseñas seguras
    private fun hashPassword(password: String): String {
        val bytes = password.toByteArray()
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(bytes)
        return digest.fold("") { str, it -> str + "%02x".format(it) }
    }

    fun registerUser(username: String, password: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("username", username)
            put("password", hashPassword(password))
        }
        val result = db.insert("users", null, values)
        db.close()
        return result != -1L
    }

    fun validateUser(username: String, password: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?", arrayOf(username, hashPassword(password)))
        val count = cursor.count
        cursor.close()
        db.close()
        return count > 0
    }

    fun logSensorData(type: String, value: Double) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("type", type)
            put("value", value)
        }
        db.insert("sensor_logs", null, values)
        db.close()
    }
}