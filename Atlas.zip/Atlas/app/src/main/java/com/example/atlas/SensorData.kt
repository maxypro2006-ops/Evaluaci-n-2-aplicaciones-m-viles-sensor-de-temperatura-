package com.example.atlas

data class SensorData(
    val temperature: Double,
    val humidity: Double,
    val status: String
)