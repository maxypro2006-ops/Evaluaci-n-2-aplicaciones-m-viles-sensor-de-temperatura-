package com.example.atlas

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.toColorInt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.PrintWriter
import java.net.Socket

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var sensorManager: TemperatureSensorManager
    private var isMonitoring = false
    private var lastReading: SensorData? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)
        sensorManager = TemperatureSensorManager(this, dbHelper)

        val tvTempDisplay = findViewById<TextView>(R.id.tvTempDisplay)
        val tvStatusDisplay = findViewById<TextView>(R.id.tvStatusDisplay)
        val tvHumidityDisplay = findViewById<TextView>(R.id.tvHumidityDisplay)
        val tvLiveBadge = findViewById<TextView>(R.id.tvLiveBadge)
        val btnToggleSensor = findViewById<Button>(R.id.btnToggleSensor)
        val etTargetIp = findViewById<EditText>(R.id.etTargetIp)
        val btnSendTransmission = findViewById<Button>(R.id.btnSendTransmission)
        val btnLogout = findViewById<ImageButton>(R.id.btnLogout)

        btnLogout.setOnClickListener {
            sensorManager.stopMonitoring()
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnToggleSensor.setOnClickListener {
            if (isMonitoring) {
                sensorManager.stopMonitoring()
                btnToggleSensor.text = "Iniciar Monitoreo Automático"
                tvLiveBadge.visibility = View.GONE
                tvStatusDisplay.text = "ESTADO: INACTIVO"
                tvStatusDisplay.setTextColor("#94A3B8".toColorInt())
                isMonitoring = false
            } else {
                tvLiveBadge.visibility = View.VISIBLE
                sensorManager.startMonitoring { reading ->
                    runOnUiThread {
                        lastReading = reading
                        tvTempDisplay.text = "${reading.temperature} °C"
                        tvHumidityDisplay.text = "Humedad Relativa: ${reading.humidity} %"
                        tvStatusDisplay.text = "ESTADO: ${reading.status}"

                        if (reading.status.contains("ALERTA", ignoreCase = true)) {
                            tvStatusDisplay.setTextColor("#EF4444".toColorInt()) // Red alert
                        } else {
                            tvStatusDisplay.setTextColor("#22C55E".toColorInt()) // Green normal
                        }
                    }
                }
                btnToggleSensor.text = "Detener Monitoreo"
                isMonitoring = true
            }
        }

        btnSendTransmission.setOnClickListener {
            val ip = etTargetIp.text.toString().trim()
            if (ip.isNotEmpty() && lastReading != null) {
                sendDataOverWifi(ip, lastReading!!)
            } else {
                Toast.makeText(this, "Ingrese IP válida y asegúrese de estar monitoreando", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendDataOverWifi(ipAddress: String, data: SensorData) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val socket = Socket(ipAddress, 8080)
                val writer = PrintWriter(socket.getOutputStream(), true)
                writer.println("TEMP:${data.temperature}|HUM:${data.humidity}|STAT:${data.status}")
                socket.close()
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Datos enviados a $ipAddress", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Error de conexión con $ipAddress", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        sensorManager.stopMonitoring()
    }
}